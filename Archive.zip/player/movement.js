import {
  THREE,
  camera
} from "../core/scene.js";

import {
  openArtwork,
  closeArtwork,
  isArtworkOpen
} from "../objects/artwork.js";

import {
  openTicketMenu,
  closeTicketMenu,
  isTicketMenuOpen
} from "../ui/ticketMenu.js";

// =====================================================
// RAYCASTER
// =====================================================

const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();

// =====================================================
// ROOMS
// =====================================================

let rooms = {};
let currentRoom = "entrance";

let previousRoom = null;
let previousPosition = null;

// =====================================================
// CAMERA MOVEMENT
// =====================================================

let targetZ = camera.position.z;
let targetY = camera.position.y;

let lookX = 0;
let lookY = 0;

let isWalking = false;
let walkTime = 0;

// =====================================================
// SETTINGS
// =====================================================

const STEP_SIZE = 2.8;
const DEFAULT_EYE_HEIGHT = 1.62;

// В комнате с подвесной экспозицией камера чуть выше
const ROOM_EYE_HEIGHTS = {
  room02: 1.9
};

const LOOK_HORIZONTAL = 0.8;
const LOOK_VERTICAL = 0.32;
const LOOK_SMOOTHNESS = 0.07;

const WALK_SMOOTHNESS = 0.08;
const HEAD_BOB_AMOUNT = 0.018;
const HEAD_BOB_SPEED = 8;

// =====================================================
// ROOM LIMITS
// =====================================================

const ROOM_LIMITS = {
  entrance: {
    startZ: 12,
    endZ: -23,

    stairStartZ: -6,
    stairEndZ: -21,

    landingHeight: 4.75
  },

  leftRoom: {
    startZ: 10,
    endZ: -27
  },

  rightRoom: {
    startZ: 10,
    endZ: -27
  },

  corridor: {
    startZ: 12,
    endZ: -155
  },

  room01: {
    startZ: 10,
    endZ: -30
  },

  room02: {
    startZ: 10,
    endZ: -31
  },

  room03: {
    startZ: 10,
    endZ: -28
  },

  room04: {
    startZ: 10,
    endZ: -28
  },

  room05: {
    startZ: 10,
    endZ: -28
  },

  room06: {
    startZ: 10,
    endZ: -28
  }
};

// =====================================================
// SETUP
// =====================================================

export function setupMovement(roomMap) {
  rooms = roomMap;

  window.addEventListener(
    "mousemove",
    handleMouseMove
  );

  window.addEventListener(
    "click",
    handleClick
  );

  window.addEventListener(
    "contextmenu",
    handleRightClick
  );

  window.addEventListener(
    "keydown",
    handleKeyDown
  );
}

// =====================================================
// MOUSE
// =====================================================

function handleMouseMove(event) {
  mouse.x =
    (event.clientX / window.innerWidth) * 2 - 1;

  mouse.y =
    -(event.clientY / window.innerHeight) * 2 + 1;

  lookX =
    event.clientX / window.innerWidth - 0.5;

  lookY =
    event.clientY / window.innerHeight - 0.5;

  updateCursor();
}

// =====================================================
// LEFT CLICK
// =====================================================

function handleClick(event) {
  event.preventDefault();

  // При открытом билетном меню
  // клики по 3D-сцене не двигают персонажа
  if (isTicketMenuOpen()) {
    return;
  }

  // При открытой работе клик закрывает просмотр
  if (isArtworkOpen()) {
    closeArtwork();
    return;
  }

  const interactiveObject =
    getClickedInteractiveObject();

  // Компьютер билетной кассы
  if (
    interactiveObject?.userData.type ===
    "ticketComputer"
  ) {
    openTicketMenu();
    return;
  }

  // Картина
  if (
    interactiveObject?.userData.type ===
    "artwork"
  ) {
    openArtwork(interactiveObject);
    return;
  }

  // Дверь
  if (
    interactiveObject?.userData.type ===
      "door" &&
    interactiveObject.userData.target
  ) {
    goToRoom(
      interactiveObject.userData.target
    );

    return;
  }

  // Пустое место — шаг вперёд
  walkForward();
}

// =====================================================
// RIGHT CLICK
// =====================================================

function handleRightClick(event) {
  event.preventDefault();

  if (isTicketMenuOpen()) {
    closeTicketMenu();
    return;
  }

  if (isArtworkOpen()) {
    closeArtwork();
    return;
  }

  // Из коридора возвращаемся
  // на верхнюю площадку главного холла
  if (currentRoom === "corridor") {
    goToEntranceFromCorridor();
    return;
  }

  // Из комнаты возвращаемся туда,
  // откуда в неё вошли
  if (
    currentRoom !== "entrance" &&
    previousRoom &&
    previousPosition
  ) {
    returnToPreviousRoom();
    return;
  }

  // В холле — обычный шаг назад
  walkBackward();
}

// =====================================================
// KEYBOARD
// =====================================================

function handleKeyDown(event) {
  if (event.key !== "Escape") {
    return;
  }

  if (isTicketMenuOpen()) {
    closeTicketMenu();
    return;
  }

  if (isArtworkOpen()) {
    closeArtwork();
  }
}

// =====================================================
// RAYCASTING
// =====================================================

function getClickedInteractiveObject() {
  const activeRoom = rooms[currentRoom];

  if (!activeRoom) {
    return null;
  }

  raycaster.setFromCamera(
    mouse,
    camera
  );

  const hits = raycaster.intersectObjects(
    activeRoom.children,
    true
  );

  if (hits.length === 0) {
    return null;
  }

  /*
    Проверяем все пересечения.

    Луч может сначала попасть:
    - в экран компьютера;
    - в подставку;
    - в раму;
    - в трос;
    - в часть арки.

    Поэтому поднимаемся вверх по parent,
    пока не найдём интерактивную группу.
  */

  for (const hit of hits) {
    let object = hit.object;

    while (
      object &&
      object !== activeRoom
    ) {
      if (
        object.userData.type ===
          "artwork" ||
        object.userData.type ===
          "door" ||
        object.userData.type ===
          "ticketComputer"
      ) {
        return object;
      }

      object = object.parent;
    }
  }

  return null;
}

// =====================================================
// CURSOR
// =====================================================

function updateCursor() {
  if (isTicketMenuOpen()) {
    document.body.style.cursor = "default";
    return;
  }

  if (isArtworkOpen()) {
    document.body.style.cursor = "zoom-out";
    return;
  }

  const object =
    getClickedInteractiveObject();

  if (
    object?.userData.type ===
    "ticketComputer"
  ) {
    document.body.style.cursor = "pointer";
    return;
  }

  if (
    object?.userData.type ===
    "artwork"
  ) {
    document.body.style.cursor = "zoom-in";
    return;
  }

  if (
    object?.userData.type ===
    "door"
  ) {
    document.body.style.cursor = "pointer";
    return;
  }

  document.body.style.cursor = "default";
}

// =====================================================
// WALK FORWARD
// =====================================================

function walkForward() {
  if (
    isArtworkOpen() ||
    isTicketMenuOpen()
  ) {
    return;
  }

  const limits =
    ROOM_LIMITS[currentRoom];

  if (!limits) {
    return;
  }

  targetZ -= STEP_SIZE;

  if (targetZ < limits.endZ) {
    targetZ = limits.endZ;
  }

  targetY =
    getEyeHeightForCurrentRoom(
      targetZ
    );

  isWalking = true;
}

// =====================================================
// WALK BACKWARD
// =====================================================

function walkBackward() {
  if (
    isArtworkOpen() ||
    isTicketMenuOpen()
  ) {
    return;
  }

  const limits =
    ROOM_LIMITS[currentRoom];

  if (!limits) {
    return;
  }

  targetZ += STEP_SIZE;

  if (targetZ > limits.startZ) {
    targetZ = limits.startZ;
  }

  targetY =
    getEyeHeightForCurrentRoom(
      targetZ
    );

  isWalking = true;
}

// =====================================================
// EYE HEIGHT
// =====================================================

function getBaseEyeHeight(roomName) {
  return (
    ROOM_EYE_HEIGHTS[roomName] ??
    DEFAULT_EYE_HEIGHT
  );
}

function getEyeHeightForCurrentRoom(z) {
  const eyeHeight =
    getBaseEyeHeight(currentRoom);

  // Во всех комнатах и коридоре пол ровный
  if (currentRoom !== "entrance") {
    return eyeHeight;
  }

  const limits =
    ROOM_LIMITS.entrance;

  // До лестницы
  if (z > limits.stairStartZ) {
    return eyeHeight;
  }

  // На верхней площадке
  if (z < limits.stairEndZ) {
    return (
      eyeHeight +
      limits.landingHeight
    );
  }

  // Плавный подъём по лестнице
  const progress =
    (limits.stairStartZ - z) /
    (
      limits.stairStartZ -
      limits.stairEndZ
    );

  return (
    eyeHeight +
    progress * limits.landingHeight
  );
}

// =====================================================
// ENTER ROOM
// =====================================================

function goToRoom(roomName) {
  if (!rooms[roomName]) {
    console.warn(
      `Room "${roomName}" was not found`
    );

    return;
  }

  previousRoom = currentRoom;

  previousPosition = {
    x: camera.position.x,
    y: camera.position.y,
    z: camera.position.z,

    rotX: camera.rotation.x,
    rotY: camera.rotation.y,
    rotZ: camera.rotation.z,

    targetZ,
    targetY
  };

  hideAllRooms();

  rooms[roomName].visible = true;
  currentRoom = roomName;

  const limits =
    ROOM_LIMITS[currentRoom];

  if (!limits) {
    console.warn(
      `ROOM_LIMITS missing for "${currentRoom}"`
    );

    return;
  }

  const eyeHeight =
    getBaseEyeHeight(currentRoom);

  camera.position.set(
    0,
    eyeHeight,
    limits.startZ
  );

  camera.rotation.set(
    0,
    0,
    0
  );

  targetZ = limits.startZ;
  targetY = eyeHeight;

  lookX = 0;
  lookY = 0;

  isWalking = false;
  walkTime = 0;

  document.body.style.cursor =
    "default";
}

// =====================================================
// RETURN TO PREVIOUS ROOM
// =====================================================

function returnToPreviousRoom() {
  if (
    !previousRoom ||
    !previousPosition ||
    !rooms[previousRoom]
  ) {
    return;
  }

  const roomToReturn =
    previousRoom;

  const savedPosition = {
    ...previousPosition
  };

  hideAllRooms();

  rooms[roomToReturn].visible = true;
  currentRoom = roomToReturn;

  camera.position.set(
    savedPosition.x,
    savedPosition.y,
    savedPosition.z
  );

  camera.rotation.set(
    savedPosition.rotX,
    savedPosition.rotY,
    savedPosition.rotZ
  );

  targetZ =
    savedPosition.targetZ ??
    savedPosition.z;

  targetY =
    savedPosition.targetY ??
    savedPosition.y;

  previousRoom = null;
  previousPosition = null;

  isWalking = false;
  walkTime = 0;

  document.body.style.cursor =
    "default";
}

// =====================================================
// CORRIDOR → ENTRANCE
// =====================================================

function goToEntranceFromCorridor() {
  if (!rooms.entrance) {
    return;
  }

  hideAllRooms();

  rooms.entrance.visible = true;
  currentRoom = "entrance";

  const entranceZ = -22;

  const entranceY =
    DEFAULT_EYE_HEIGHT +
    ROOM_LIMITS.entrance.landingHeight;

  camera.position.set(
    0,
    entranceY,
    entranceZ
  );

  targetZ = entranceZ;
  targetY = entranceY;

  // Смотрим со стороны двери обратно в холл
  camera.rotation.set(
    0,
    Math.PI,
    0
  );

  previousRoom = null;
  previousPosition = null;

  isWalking = false;
  walkTime = 0;

  document.body.style.cursor =
    "default";
}

// =====================================================
// HIDE ALL ROOMS
// =====================================================

function hideAllRooms() {
  Object.values(rooms).forEach(
    (room) => {
      if (room) {
        room.visible = false;
      }
    }
  );
}

// =====================================================
// ANIMATION
// =====================================================

export function updateMovement() {
  /*
    Когда открыто HTML-меню кассы,
    полностью замораживаем 3D-камеру.
  */

  if (isTicketMenuOpen()) {
    isWalking = false;
    return;
  }

  /*
    При просмотре картины персонаж не ходит,
    но плавный взгляд мышкой остаётся.
  */

  if (isArtworkOpen()) {
    camera.rotation.y +=
      (
        -lookX * LOOK_HORIZONTAL -
        camera.rotation.y
      ) *
      LOOK_SMOOTHNESS;

    camera.rotation.x +=
      (
        -lookY * LOOK_VERTICAL -
        camera.rotation.x
      ) *
      LOOK_SMOOTHNESS;

    return;
  }

  const distanceZ =
    Math.abs(
      targetZ -
      camera.position.z
    );

  const distanceY =
    Math.abs(
      targetY -
      camera.position.y
    );

  if (
    distanceZ < 0.025 &&
    distanceY < 0.025
  ) {
    isWalking = false;
  }

  if (isWalking) {
    walkTime += 0.18;
  }

  const headBob =
    isWalking
      ? Math.sin(
          walkTime *
          HEAD_BOB_SPEED
        ) *
        HEAD_BOB_AMOUNT
      : 0;

  camera.position.z +=
    (
      targetZ -
      camera.position.z
    ) *
    WALK_SMOOTHNESS;

  camera.position.y +=
    (
      targetY +
      headBob -
      camera.position.y
    ) *
    WALK_SMOOTHNESS;

  camera.rotation.y +=
    (
      -lookX * LOOK_HORIZONTAL -
      camera.rotation.y
    ) *
    LOOK_SMOOTHNESS;

  camera.rotation.x +=
    (
      -lookY * LOOK_VERTICAL -
      camera.rotation.x
    ) *
    LOOK_SMOOTHNESS;
}