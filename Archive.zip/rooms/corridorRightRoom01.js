import {
  THREE,
  scene
} from "../core/scene.js";

import {
  floorMaterial,
  wallMaterial
} from "../core/materials.js";

import {
  createHangingArtwork,
  createFloorArtwork
} from "../objects/artwork.js";

export function createCorridorRightRoom01() {
  const room = new THREE.Group();

  room.name = "Corridor Right Room 01";
  room.visible = false;

  // ===================================================
  // РАЗМЕРЫ КОМНАТЫ
  // ===================================================

  const roomWidth = 36;
  const roomDepth = 44;
  const roomHeight = 11;

  const centerZ = -11;
  const backWallZ = -33;

  // ===================================================
  // ПОЛ
  // ===================================================

  const floor = new THREE.Mesh(
    new THREE.BoxGeometry(
      roomWidth,
      0.14,
      roomDepth
    ),
    floorMaterial
  );

  floor.position.set(
    0,
    -0.07,
    centerZ
  );

  floor.receiveShadow = true;

  room.add(floor);

  // ===================================================
  // СТЕНЫ
  // ===================================================

  const leftWall = new THREE.Mesh(
    new THREE.BoxGeometry(
      1.2,
      roomHeight,
      roomDepth
    ),
    wallMaterial
  );

  leftWall.position.set(
    -roomWidth / 2,
    roomHeight / 2,
    centerZ
  );

  room.add(leftWall);

  const rightWall = new THREE.Mesh(
    new THREE.BoxGeometry(
      1.2,
      roomHeight,
      roomDepth
    ),
    wallMaterial
  );

  rightWall.position.set(
    roomWidth / 2,
    roomHeight / 2,
    centerZ
  );

  room.add(rightWall);

  const backWall = new THREE.Mesh(
    new THREE.BoxGeometry(
      roomWidth,
      roomHeight,
      1.2
    ),
    wallMaterial
  );

  backWall.position.set(
    0,
    roomHeight / 2,
    backWallZ
  );

  room.add(backWall);

  // ===================================================
  // ВЕРХНЯЯ МЕТАЛЛИЧЕСКАЯ РЕЙКА
  // ===================================================

  const railMaterial =
    new THREE.MeshStandardMaterial({
      color: 0x2c2d30,
      roughness: 0.7,
      metalness: 0.55
    });

  const rail = new THREE.Mesh(
    new THREE.CylinderGeometry(
      0.06,
      0.06,
      29,
      12
    ),
    railMaterial
  );

  rail.rotation.z = Math.PI / 2;
  rail.position.set(
    0,
    10.3,
    -13
  );

  room.add(rail);

  // ===================================================
  // ПОДВЕСНЫЕ РАБОТЫ — 6
  // ===================================================

  room.add(
    createHangingArtwork({
      id: "room02-hanging-01",
      position: new THREE.Vector3(
        -9.5,
        5,
        -9
      ),
      width: 1.8,
      height: 2.7,
      ceilingY: 10.3
    })
  );

  room.add(
    createHangingArtwork({
      id: "room02-hanging-02",
      position: new THREE.Vector3(
        -5.5,
        5.6,
        -12.5
      ),
      width: 2.5,
      height: 3.5,
      ceilingY: 10.3
    })
  );

  // Главная центральная работа
  room.add(
    createHangingArtwork({
      id: "room02-hanging-main",
      position: new THREE.Vector3(
        0,
        5.8,
        -17
      ),
      width: 4.2,
      height: 5.7,
      ceilingY: 10.3
    })
  );

  room.add(
    createHangingArtwork({
      id: "room02-hanging-04",
      position: new THREE.Vector3(
        5.4,
        5.2,
        -13.4
      ),
      width: 1.5,
      height: 3,
      ceilingY: 10.3
    })
  );

  room.add(
    createHangingArtwork({
      id: "room02-hanging-05",
      position: new THREE.Vector3(
        9.3,
        5.4,
        -10
      ),
      width: 2,
      height: 2.8,
      ceilingY: 10.3
    })
  );

  // Горизонтальная работа глубже в комнате
  room.add(
    createHangingArtwork({
      id: "room02-hanging-06",
      position: new THREE.Vector3(
        4,
        4.3,
        -24
      ),
      width: 4.8,
      height: 2.2,
      ceilingY: 10.3
    })
  );

  // ===================================================
  // РАБОТЫ НА ПОЛУ — 4
  // ===================================================

  room.add(
    createFloorArtwork({
      id: "room02-floor-01",
      position: new THREE.Vector3(
        -9,
        0,
        -6
      ),
      width: 3,
      depth: 2
    })
  );

  room.add(
    createFloorArtwork({
      id: "room02-floor-02",
      position: new THREE.Vector3(
        -3.5,
        0,
        -20
      ),
      width: 3.5,
      depth: 2.3
    })
  );

  room.add(
    createFloorArtwork({
      id: "room02-floor-03",
      position: new THREE.Vector3(
        7.8,
        0,
        -19
      ),
      width: 3,
      depth: 2
    })
  );

  room.add(
    createFloorArtwork({
      id: "room02-floor-04",
      position: new THREE.Vector3(
        0,
        0,
        -28
      ),
      width: 4.4,
      depth: 2.6
    })
  );

  // ===================================================
  // СВЕТ ВНУТРИ ЭТОЙ КОМНАТЫ
  // ===================================================

  const roomAmbient = new THREE.PointLight(
    0xd7d9df,
    1.3,
    50
  );

  roomAmbient.position.set(
    0,
    8,
    -8
  );

  room.add(roomAmbient);

  const artworkLight =
    new THREE.SpotLight(
      0xfff1d4,
      4,
      35,
      Math.PI / 4,
      0.75,
      1
    );

  artworkLight.position.set(
    -7,
    9.5,
    -2
  );

  artworkLight.target.position.set(
    0,
    4,
    -17
  );

  room.add(artworkLight);
  room.add(artworkLight.target);

  const backLight =
    new THREE.PointLight(
      0xdde5ff,
      0.9,
      35
    );

  backLight.position.set(
    8,
    5,
    -26
  );

  room.add(backLight);

  room.traverse((child) => {
    if (child.isMesh) {
      child.receiveShadow = true;
    }
  });

  scene.add(room);

  return room;
}