let ticketMenu = null;
let ticketButton = null;

let menuOpen = false;

export function setupTicketMenu() {
  ticketMenu =
    document.querySelector(
      "#ticket-menu"
    );

  ticketButton =
    document.querySelector(
      "#ticket-menu-button"
    );

  const closeButton =
    document.querySelector(
      "#ticket-menu-close"
    );

  closeButton?.addEventListener(
    "click",
    closeTicketMenu
  );

  ticketMenu?.addEventListener(
    "click",
    (event) => {
      if (
        event.target === ticketMenu
      ) {
        closeTicketMenu();
      }
    }
  );

  ticketButton?.addEventListener(
    "click",
    reserveTicket
  );

  window.addEventListener(
    "keydown",
    (event) => {
      if (
        event.key === "Escape" &&
        menuOpen
      ) {
        closeTicketMenu();
      }
    }
  );
}

export function openTicketMenu() {
  if (!ticketMenu) {
    return;
  }

  menuOpen = true;

  ticketMenu.classList.add(
    "visible"
  );

  document.body.style.cursor =
    "default";
}

export function closeTicketMenu() {
  if (!ticketMenu) {
    return;
  }

  menuOpen = false;

  ticketMenu.classList.remove(
    "visible"
  );
}

export function isTicketMenuOpen() {
  return menuOpen;
}

function reserveTicket() {
  if (!ticketButton) {
    return;
  }

  ticketButton.textContent =
    "TICKET RESERVED";

  ticketButton.classList.add(
    "reserved"
  );

  window.setTimeout(() => {
    closeTicketMenu();

    ticketButton.textContent =
      "GET TICKET";

    ticketButton.classList.remove(
      "reserved"
    );
  }, 900);
}