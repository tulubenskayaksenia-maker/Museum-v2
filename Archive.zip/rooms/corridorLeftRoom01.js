import {
  THREE,
  scene
} from "../core/scene.js";

import {
  floorMaterial,
  wallMaterial
} from "../core/materials.js";

import {
  createWallArtwork
} from "../objects/artwork.js";

export function createCorridorLeftRoom01() {
  const room = new THREE.Group();

  room.name = "Corridor Left Room 01";
  room.visible = false;

  // ===================================================
  // РАЗМЕРЫ КОМНАТЫ
  // ===================================================

  const roomWidth = 38;
  const roomDepth = 46;
  const roomHeight = 12;

  const centerZ = -12;
  const backWallZ = -35;

  // ===================================================
  // МАТЕРИАЛЫ
  // ===================================================

  const panelMaterial =
    new THREE.MeshStandardMaterial({
      color: 0xd4d5d2,
      roughness: 0.92,
      metalness: 0
    });

  const panelSideMaterial =
    new THREE.MeshStandardMaterial({
      color: 0xbfc0bd,
      roughness: 0.95,
      metalness: 0
    });

  // ===================================================
  // ПОЛ
  // ===================================================

  const floor = new THREE.Mesh(
    new THREE.BoxGeometry(
      roomWidth,
      0.14,
      roomDepth
    ),
    floorMaterial
  );

  floor.position.set(
    0,
    -0.07,
    centerZ
  );

  floor.receiveShadow = true;
  room.add(floor);

  // ===================================================
  // СТЕНЫ КОМНАТЫ
  // ===================================================

  const leftWall = new THREE.Mesh(
    new THREE.BoxGeometry(
      1.2,
      roomHeight,
      roomDepth
    ),
    wallMaterial
  );

  leftWall.position.set(
    -roomWidth / 2,
    roomHeight / 2,
    centerZ
  );

  room.add(leftWall);

  const rightWall = new THREE.Mesh(
    new THREE.BoxGeometry(
      1.2,
      roomHeight,
      roomDepth
    ),
    wallMaterial
  );

  rightWall.position.set(
    roomWidth / 2,
    roomHeight / 2,
    centerZ
  );

  room.add(rightWall);

  const backWall = new THREE.Mesh(
    new THREE.BoxGeometry(
      roomWidth,
      roomHeight,
      1.2
    ),
    wallMaterial
  );

  backWall.position.set(
    0,
    roomHeight / 2,
    backWallZ
  );

  room.add(backWall);

  // ===================================================
  // ФУНКЦИЯ СОЗДАНИЯ ПАНЕЛИ
  // ===================================================

  function createPanel({
    id,
    x,
    z,
    width = 4,
    height = 9.6,
    depth = 0.5,
    rotationY = 0,
    artworkWidth = 2.2,
    artworkHeight = 3,
    artworkY = 4.8,
    artworkSide = "front"
  }) {
    const panel = new THREE.Group();
    panel.name = id;

    const block = new THREE.Mesh(
      new THREE.BoxGeometry(
        width,
        height,
        depth
      ),
      [
        panelSideMaterial,
        panelSideMaterial,
        panelMaterial,
        panelMaterial,
        panelMaterial,
        panelMaterial
      ]
    );

    block.position.y = height / 2;
    block.castShadow = true;
    block.receiveShadow = true;

    panel.add(block);

    const frontZ =
      artworkSide === "front"
        ? depth / 2 + 0.09
        : -depth / 2 - 0.09;

    const artworkRotation =
      artworkSide === "front"
        ? 0
        : Math.PI;

    const artwork =
      createWallArtwork({
        id: `${id}-artwork`,
        position: new THREE.Vector3(
          0,
          artworkY,
          frontZ
        ),
        rotationY: artworkRotation,
        width: artworkWidth,
        height: artworkHeight
      });

    panel.add(artwork);

    panel.position.set(
      x,
      0,
      z
    );

    panel.rotation.y = rotationY;

    room.add(panel);

    return panel;
  }

  // ===================================================
  // ПЕРВЫЙ РЯД ПАНЕЛЕЙ
  // ===================================================

  createPanel({
    id: "room01-panel-01",
    x: -11,
    z: -5,
    width: 4.2,
    artworkWidth: 2,
    artworkHeight: 2.8,
    artworkY: 4.6
  });

  createPanel({
    id: "room01-panel-02",
    x: -3.8,
    z: -5,
    width: 4.8,
    artworkWidth: 3.1,
    artworkHeight: 4.4,
    artworkY: 5
  });

  createPanel({
    id: "room01-panel-03",
    x: 4.2,
    z: -5,
    width: 4.1,
    artworkWidth: 1.8,
    artworkHeight: 3,
    artworkY: 4.7
  });

  createPanel({
    id: "room01-panel-04",
    x: 11,
    z: -5,
    width: 4.6,
    artworkWidth: 3,
    artworkHeight: 3.8,
    artworkY: 4.9
  });

  // ===================================================
  // ВТОРОЙ РЯД — НЕМНОГО СМЕЩЁН
  // ===================================================

  createPanel({
    id: "room01-panel-05",
    x: -8,
    z: -16,
    width: 5,
    artworkWidth: 3.5,
    artworkHeight: 4.8,
    artworkY: 5.1,
    artworkSide: "front"
  });

  createPanel({
    id: "room01-panel-06",
    x: 0,
    z: -16,
    width: 4,
    artworkWidth: 2,
    artworkHeight: 3,
    artworkY: 4.7,
    artworkSide: "front"
  });

  createPanel({
    id: "room01-panel-07",
    x: 8,
    z: -16,
    width: 5,
    artworkWidth: 3.2,
    artworkHeight: 4.3,
    artworkY: 5,
    artworkSide: "front"
  });

  // ===================================================
  // ТРЕТИЙ РЯД
  // ===================================================

  createPanel({
    id: "room01-panel-08",
    x: -10,
    z: -27,
    width: 4.2,
    artworkWidth: 2.1,
    artworkHeight: 3.1,
    artworkY: 4.7
  });

  createPanel({
    id: "room01-panel-main",
    x: 0,
    z: -27,
    width: 6.2,
    artworkWidth: 4.4,
    artworkHeight: 5.8,
    artworkY: 5.2
  });

  createPanel({
    id: "room01-panel-10",
    x: 10,
    z: -27,
    width: 4.2,
    artworkWidth: 2.2,
    artworkHeight: 3.2,
    artworkY: 4.8
  });

  // ===================================================
  // БОЛЬШАЯ РАБОТА НА ЗАДНЕЙ СТЕНЕ
  // ===================================================

  const backArtwork =
    createWallArtwork({
      id: "room01-back-main",
      position: new THREE.Vector3(
        0,
        5.6,
        backWallZ + 0.7
      ),
      width: 10,
      height: 5.2
    });

  room.add(backArtwork);

  // ===================================================
  // СВЕТ
  // ===================================================

  const roomFill =
    new THREE.HemisphereLight(
      0xe7e9ee,
      0x303238,
      0.75
    );

  room.add(roomFill);

  const frontLight =
    new THREE.PointLight(
      0xffffff,
      1.5,
      45
    );

  frontLight.position.set(
    0,
    8,
    8
  );

  room.add(frontLight);

  const centerLight =
    new THREE.PointLight(
      0xdde6ff,
      1.2,
      38
    );

  centerLight.position.set(
    0,
    7,
    -14
  );

  room.add(centerLight);

  const backLight =
    new THREE.PointLight(
      0xffffff,
      1,
      32
    );

  backLight.position.set(
    0,
    6,
    -29
  );

  room.add(backLight);

  room.traverse((child) => {
    if (child.isMesh) {
      child.receiveShadow = true;
    }
  });

  scene.add(room);

  return room;
}