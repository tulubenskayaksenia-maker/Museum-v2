import { createArchPortal } from "./arch.js";
import { ROOM } from "../config/layout.js";
import { getLandingLevel } from "./stairs.js";

export function createMainPortal(parent) {
  const portal = createArchPortal({
    target: "corridor"
  });

  portal.name = "Main Corridor Portal";
  portal.position.set(0, getLandingLevel(), ROOM.backWallZ + 0.72);

  parent.add(portal);
}