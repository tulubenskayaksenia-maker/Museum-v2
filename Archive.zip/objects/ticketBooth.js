import { THREE } from "../core/scene.js";
import { ARCHES } from "../config/layout.js";

// =====================================================
// MATERIALS
// =====================================================

const counterMaterial =
  new THREE.MeshStandardMaterial({
    color: 0x36383e,
    roughness: 0.84,
    metalness: 0.03
  });

const darkMaterial =
  new THREE.MeshStandardMaterial({
    color: 0x141519,
    roughness: 0.7,
    metalness: 0.12
  });

const metalMaterial =
  new THREE.MeshStandardMaterial({
    color: 0x555a64,
    roughness: 0.5,
    metalness: 0.55
  });

const screenBodyMaterial =
  new THREE.MeshStandardMaterial({
    color: 0x0d0e12,
    roughness: 0.5,
    metalness: 0.25
  });

const screenMaterial =
  new THREE.MeshStandardMaterial({
    color: 0x172033,
    emissive: 0x6f9bdc,
    emissiveIntensity: 0.65,
    roughness: 0.4,
    metalness: 0
  });

// =====================================================
// MAIN
// =====================================================

export function createTicketBooth(parent) {
  const booth = new THREE.Group();

  booth.name = "Ticket Booth";

  // Справа в главном холле
  booth.position.set(
    ARCHES.sideX - 1.35,
    0,
    ARCHES.sideZ + 0.5
  );

  // Разворачиваем лицом в холл
  booth.rotation.y = -Math.PI / 2;

  createCounter(booth);

  createComputer(
    booth,
    -1.45,
    "Ticket Computer Left"
  );

  createComputer(
    booth,
    1.45,
    "Ticket Computer Right"
  );

  createTicketTray(booth);
  createSign(booth);
  createLights(booth);

  booth.traverse((child) => {
    if (child.isMesh) {
      child.receiveShadow = true;
    }
  });

  parent.add(booth);

  return booth;
}

// =====================================================
// COUNTER
// =====================================================

function createCounter(parent) {
  const counter = new THREE.Group();
  counter.name = "Ticket Counter";

  const base = new THREE.Mesh(
    new THREE.BoxGeometry(
      5.3,
      0.72,
      1.05
    ),
    darkMaterial
  );

  base.position.set(0, 0.36, 0);
  counter.add(base);

  const body = new THREE.Mesh(
    new THREE.BoxGeometry(
      6.2,
      1.32,
      1.35
    ),
    counterMaterial
  );

  body.position.set(0, 1.22, 0);
  counter.add(body);

  const top = new THREE.Mesh(
    new THREE.BoxGeometry(
      6.55,
      0.16,
      1.62
    ),
    darkMaterial
  );

  top.position.set(0, 1.96, 0);
  counter.add(top);

  const sideExtension =
    new THREE.Mesh(
      new THREE.BoxGeometry(
        1.45,
        0.92,
        1.62
      ),
      counterMaterial
    );

  sideExtension.position.set(
    3.35,
    0.75,
    0
  );

  counter.add(sideExtension);

  parent.add(counter);
}

// =====================================================
// COMPUTER
// =====================================================

function createComputer(
  parent,
  x,
  name
) {
  const computer = new THREE.Group();

  computer.name = name;

  // Raycaster будет искать именно это
  computer.userData.type =
    "ticketComputer";

  const monitorBody = new THREE.Mesh(
    new THREE.BoxGeometry(
      1.42,
      0.94,
      0.12
    ),
    screenBodyMaterial
  );

  computer.add(monitorBody);

  const display = new THREE.Mesh(
    new THREE.PlaneGeometry(
      1.27,
      0.79
    ),
    screenMaterial.clone()
  );

  display.position.z = 0.066;
  computer.add(display);

  const stand = new THREE.Mesh(
    new THREE.BoxGeometry(
      0.13,
      0.56,
      0.13
    ),
    metalMaterial
  );

  stand.position.y = -0.72;
  computer.add(stand);

  const standBase = new THREE.Mesh(
    new THREE.BoxGeometry(
      0.72,
      0.08,
      0.42
    ),
    metalMaterial
  );

  standBase.position.y = -1;
  computer.add(standBase);

  computer.position.set(
    x,
    2.72,
    0
  );

  computer.rotation.x = -0.07;

  parent.add(computer);
}

// =====================================================
// TICKET TRAY
// =====================================================

function createTicketTray(parent) {
  const tray = new THREE.Mesh(
    new THREE.BoxGeometry(
      1.5,
      0.06,
      0.66
    ),
    metalMaterial
  );

  tray.position.set(
    0,
    2.07,
    0.3
  );

  parent.add(tray);

  const slot = new THREE.Mesh(
    new THREE.BoxGeometry(
      0.92,
      0.035,
      0.12
    ),
    new THREE.MeshBasicMaterial({
      color: 0x020202
    })
  );

  slot.position.set(
    0,
    2.105,
    0.16
  );

  parent.add(slot);
}

// =====================================================
// SIGN
// =====================================================

function createSign(parent) {
  const sign = new THREE.Group();
  sign.name = "Tickets Sign";

  const signWidth = 5.2;
  const signHeight = 0.75;

  const signBase = new THREE.Mesh(
    new THREE.BoxGeometry(
      signWidth,
      signHeight,
      0.11
    ),
    metalMaterial
  );

  sign.add(signBase);

  const texture =
    createTextTexture("TICKETS");

  const textPlane = new THREE.Mesh(
    new THREE.PlaneGeometry(
      signWidth - 0.18,
      signHeight - 0.14
    ),
    new THREE.MeshBasicMaterial({
      map: texture,
      transparent: true,
      depthWrite: false
    })
  );

  textPlane.position.z = 0.061;
  sign.add(textPlane);

  sign.position.set(
    0,
    5.85,
    0
  );

  parent.add(sign);

  createCable(parent, -1.75);
  createCable(parent, 1.75);
}

function createCable(parent, x) {
  const cable = new THREE.Mesh(
    new THREE.CylinderGeometry(
      0.014,
      0.014,
      2.3,
      8
    ),
    metalMaterial
  );

  cable.position.set(
    x,
    7.35,
    0
  );

  parent.add(cable);
}

// =====================================================
// LIGHTS
// =====================================================

function createLights(parent) {
  const upperLight =
    new THREE.PointLight(
      0xdce6f8,
      1.15,
      10,
      2
    );

  upperLight.position.set(
    0,
    4.7,
    1
  );

  parent.add(upperLight);

  const screenGlow =
    new THREE.PointLight(
      0x91b7f2,
      0.65,
      5.5,
      2
    );

  screenGlow.position.set(
    0,
    2.8,
    0.8
  );

  parent.add(screenGlow);
}

// =====================================================
// TEXT TEXTURE
// =====================================================

function createTextTexture(text) {
  const canvas =
    document.createElement("canvas");

  canvas.width = 1024;
  canvas.height = 180;

  const context =
    canvas.getContext("2d");

  context.clearRect(
    0,
    0,
    canvas.width,
    canvas.height
  );

  context.font =
    "500 70px Arial, Helvetica, sans-serif";

  context.textAlign = "center";
  context.textBaseline = "middle";

  context.fillStyle = "#eef3fb";

  context.shadowColor =
    "rgba(175, 205, 255, 0.7)";

  context.shadowBlur = 18;

  context.fillText(
    text,
    canvas.width / 2,
    canvas.height / 2
  );

  const texture =
    new THREE.CanvasTexture(canvas);

  texture.colorSpace =
    THREE.SRGBColorSpace;

  texture.minFilter =
    THREE.LinearFilter;

  texture.magFilter =
    THREE.LinearFilter;

  return texture;
}