import { THREE } from "../core/scene.js";
import {
  archMaterial,
  darkMaterial
} from "../core/materials.js";
import { ARCHES } from "../config/layout.js";

// =====================================================
// SIDE ARCHES IN THE ENTRANCE HALL
// =====================================================

export function createSideArches(parent) {
  // Только левая боковая арка.
  // Справа вместо арки будет билетная касса.
  const leftArch = createArchPortal({
    target: "leftRoom"
  });

  leftArch.name = "Left Hall Arch";

  leftArch.position.set(
    -ARCHES.sideX,
    ARCHES.sideY,
    ARCHES.sideZ
  );

  leftArch.rotation.y = Math.PI / 2;

  parent.add(leftArch);
}

// =====================================================
// UNIVERSAL ARCH
// Используется дверью наверху и дверями коридора
// =====================================================

export function createArchPortal({
  width = 5.2,
  height = 7.4,
  depth = 1.3,
  openingWidth = 3.6,
  openingHeight = 6.2,
  target = null
} = {}) {
  const arch = new THREE.Group();
  arch.name = "Arch Portal";

  if (target) {
    arch.userData.type = "door";
    arch.userData.target = target;
  }

  const sideThickness =
    (width - openingWidth) / 2;

  const radius =
    openingWidth / 2;

  const straightHeight =
    openingHeight - radius;

  // Тёмный проём
  const opening = createFilledArchShape(
    openingWidth,
    openingHeight,
    darkMaterial
  );

  opening.position.set(
    0,
    0,
    -depth * 0.48
  );

  arch.add(opening);

  // Левая колонна
  const leftColumn = new THREE.Mesh(
    new THREE.BoxGeometry(
      sideThickness,
      straightHeight,
      depth
    ),
    archMaterial
  );

  leftColumn.position.set(
    -openingWidth / 2 - sideThickness / 2,
    straightHeight / 2,
    0
  );

  arch.add(leftColumn);

  // Правая колонна
  const rightColumn = new THREE.Mesh(
    new THREE.BoxGeometry(
      sideThickness,
      straightHeight,
      depth
    ),
    archMaterial
  );

  rightColumn.position.set(
    openingWidth / 2 + sideThickness / 2,
    straightHeight / 2,
    0
  );

  arch.add(rightColumn);

  // Полукруглая верхняя часть
  const blockCount = 28;
  const archRadius =
    radius + sideThickness / 2;

  for (let i = 0; i <= blockCount; i++) {
    const progress = i / blockCount;
    const angle =
      Math.PI - progress * Math.PI;

    const block = new THREE.Mesh(
      new THREE.BoxGeometry(
        sideThickness * 0.95,
        sideThickness * 0.95,
        depth
      ),
      archMaterial
    );

    block.position.set(
      Math.cos(angle) * archRadius,
      straightHeight +
        Math.sin(angle) * archRadius,
      0
    );

    block.rotation.z =
      angle - Math.PI / 2;

    arch.add(block);
  }

  arch.traverse((child) => {
    if (child.isMesh) {
      child.castShadow = true;
      child.receiveShadow = true;
    }
  });

  return arch;
}

function createFilledArchShape(
  width,
  height,
  material
) {
  const radius = width / 2;
  const straightHeight =
    height - radius;

  const shape = new THREE.Shape();

  shape.moveTo(-width / 2, 0);
  shape.lineTo(
    -width / 2,
    straightHeight
  );

  shape.absarc(
    0,
    straightHeight,
    radius,
    Math.PI,
    0,
    true
  );

  shape.lineTo(width / 2, 0);
  shape.closePath();

  return new THREE.Mesh(
    new THREE.ShapeGeometry(shape),
    material
  );
}