import {
  scene,
  camera,
  renderer
} from "./core/scene.js";

import {
  createSky
} from "./environment/sky.js";

import {
  createLights
} from "./core/lights.js";

import {
  createEntrance
} from "./rooms/entrance.js";

import {
  createSideRoom
} from "./rooms/sideRoom.js";

import {
  createCorridor
} from "./rooms/corridor.js";

import {
  createCorridorLeftRoom01
} from "./rooms/corridorLeftRoom01.js";

import {
  createCorridorRightRoom01
} from "./rooms/corridorRightRoom01.js";

import {
  setupMovement,
  updateMovement
} from "./player/movement.js";

import {
  updateArtworkViewer
} from "./objects/artwork.js";

import {
  setupTicketMenu
} from "./ui/ticketMenu.js";

// =====================================================
// ENVIRONMENT
// =====================================================

createSky();
createLights();

// Меню билетной кассы
setupTicketMenu();

// =====================================================
// ROOMS
// =====================================================

const entrance =
  createEntrance();

const leftRoom =
  createSideRoom("Left Room");

const rightRoom =
  createSideRoom("Right Room");

const corridor =
  createCorridor();

// Первая комната слева в коридоре
const room01 =
  createCorridorLeftRoom01();

// Первая комната справа в коридоре
const room02 =
  createCorridorRightRoom01();

const room03 =
  createSideRoom("Room 03");

const room04 =
  createSideRoom("Room 04");

const room05 =
  createSideRoom("Room 05");

const room06 =
  createSideRoom("Room 06");

// =====================================================
// MOVEMENT
// =====================================================

setupMovement({
  entrance,
  leftRoom,
  rightRoom,
  corridor,
  room01,
  room02,
  room03,
  room04,
  room05,
  room06
});

// =====================================================
// ANIMATION
// =====================================================

function animate() {
  requestAnimationFrame(animate);

  updateMovement();
  updateArtworkViewer();

  renderer.render(
    scene,
    camera
  );
}

animate();